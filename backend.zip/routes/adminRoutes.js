const express = require('express');
const { registerAdmin, verifyOTP, loginAdmin, getDoctorList,getAllQueues,deleteQueueById,updateQueueStatus ,getAllPatients,updateDoctorFees} = require('../controllers/adminController');
// adminRouter.js

const verifyJWT = require('../middlewares/auth'); // Import verifyJWT
const verifyOtpToken = require('../middlewares/verifyOtpToken')
const router = express.Router();
// Admin Registration Route
router.post('/register', registerAdmin);

// OTP Verification Route for Admin
router.post('/verify-otp', verifyOTP);

// Admin Login Route
router.post('/login', loginAdmin);

// Get Doctor List Route (for Admin Dashboard)
router.get('/doctors', verifyJWT, getDoctorList); // Protect this route

//Example protected route that requires verified OTP
router.get('/adminData', verifyJWT, verifyOtpToken, (req, res)=>{
    res.json({message: "admin data"})
})
router.get('/queues', verifyJWT, getAllQueues);
router.get('/allpatients', verifyJWT, getAllPatients);
router.delete('/queue/:id', verifyJWT, deleteQueueById);


router.patch('/queue/:id/status', verifyJWT, updateQueueStatus);

router.put('/update-fees', updateDoctorFees);
module.exports = router;