const express = require('express');
const router = express.Router();
const upload = require('../middlewares/upload');
const doctorController = require('../controllers/doctorController');

router.post('/add', upload.single('image'), doctorController.addDoctor);
router.get('/hospital/:hospitalId', doctorController.getDoctorsByHospital);
router.get('/:doctorId', doctorController.getDoctorById);

module.exports = router;
