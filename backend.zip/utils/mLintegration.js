const axios = require('axios'); // or use any other method to call your ML model

// Function to predict appointment time using the ML model
const predictAppointmentTime = async (doctorId, patientId) => {
  try {
    // Replace with your actual API or model call logic
    const response = await axios.post('http://ML_SERVER_URL/predict', {
      doctorId,
      patientId,
    });

    if (response.data && response.data.predictedTime) {
      return response.data.predictedTime;
    } else {
      throw new Error('Prediction failed');
    }
  } catch (error) {
    console.error('Error during time prediction:', error);
    throw error;
  }
};

module.exports = { predictAppointmentTime };
