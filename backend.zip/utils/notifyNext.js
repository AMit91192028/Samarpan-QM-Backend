async function notifyNextInQueue(queue) {
    try {
      // Get the next confirmed queue entry for the same doctor
      const nextQueue = await Queue.findOne({
        doctorId: queue.doctorId,
        status: 'Booked',  // We notify the next person who hasn't confirmed yet
      }).sort({ createdAt: 1 });  // Sort by creation time to get the first in line
  
      if (nextQueue) {
        const nextPatient = await Queue.findById(nextQueue._id);
  
        if (nextPatient) {
          const message = `Your turn is up! Please visit Dr. ${nextPatient.doctorId} at your scheduled time.`;
          await sendSMS(nextPatient.phoneNumber, message);  // Send SMS to the next person in the queue
          console.log('Next person notified!');
        }
      }
    } catch (error) {
      console.error('Error notifying next in queue:', error);
    }
  }
  module.exports = { notifyNextInQueue };