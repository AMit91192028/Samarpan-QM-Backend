const otpGenerator = require('otp-generator');

// Generate OTP
const generateOTP = () => {
  return otpGenerator.generate(6, { upperCase: false, specialChars: false, digits: true });
};

// Check if OTP is expired
const isOTPExpired = (otpExpiresAt) => {
  return new Date() > otpExpiresAt;
};

module.exports = {
  generateOTP,
  isOTPExpired,
};
