const mongoose = require('mongoose');

const queueSchema = new mongoose.Schema({
  patientName: { type: String, required: true },
  age: { type: Number, required: true },
  diseaseDescription: { type: String, required: true },
  phoneNumber: { type: String, required: true },
  doctorId: { type: mongoose.Schema.Types.ObjectId, ref: 'Doctor', required: true },
  hospitalId: { type: mongoose.Schema.Types.ObjectId, ref: 'Hospital', required: true },
  status: { type: String, default: 'Booked' },
  tokenNumber: { type: String, required: true, unique: true },
  otp: { type: String, required: true },
  emergency: { type: Boolean, default: false }, // Emergency flag
  fee: { type: Number, required: true }, // Fee for the booking, can be normal or emergency fee
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Queue', queueSchema);
