// app.js

const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const cors = require('cors');

// Routes
const hospitalRoutes = require('./routes/hospitalRoutes');
const queueBookingRouter = require('./routes/queueBooking');
const adminRoutes = require('./routes/adminRoutes');
const doctorRoutes = require('./routes/doctorRoutes');
const userRoutes = require('./routes/userRoutes');

dotenv.config();

const app = express();

app.use(express.json());
app.use(cors());

// Use Routes
app.use('/uploads', express.static('../server/public/images/uploads'));
app.use('/api/hospitals', hospitalRoutes);
app.use('/api/queue', queueBookingRouter);
app.use('/api/admin', adminRoutes);
app.use('/api/doctors', doctorRoutes);
app.use('/api/users', userRoutes);

// MongoDB & Server
const PORT = process.env.PORT || 4001;
const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/queue-management';

mongoose.connect(MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => {
  console.log('✅ MongoDB connected');
  app.listen(PORT, () => {
    console.log(`🚀 Server is running at http://localhost:${PORT}`);
  });
})
.catch((err) => {
  console.error('❌ MongoDB connection error:', err.message);
});

// Error handling middleware (place after routes)
app.use((err, req, res, next) => {
    console.error('🔥 Error:', err.stack);
    res.status(500).json({ message: 'Internal Server Error' });
});

// 404 handler (place after routes and error handler)
app.use((req, res, next) => {
    res.status(404).json({ message: 'Not Found' });
});

module.exports = app; // Export the app for testing or other purposes