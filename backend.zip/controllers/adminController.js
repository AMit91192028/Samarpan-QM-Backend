const Admin = require('../models/Admin');
const Doctor = require('../models/Doctor');
const Hospital = require('../models/Hospital'); // Import Hospital model
const { generateOTP, isOTPExpired } = require('../utils/otpUtils');
const { sendEmail } = require('../utils/mailer');
const { sendSms } = require('../utils/sendSms');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const Queue = require('../models/Queue');
// Admin Registration
const registerAdmin = async (req, res) => {
  await body('name').notEmpty().withMessage('Name is required').run(req);
  await body('hospitalId').notEmpty().withMessage('Hospital ID is required').run(req);
  await body('phone').notEmpty().withMessage('Phone is required').run(req);
  await body('email').isEmail().withMessage('Invalid email').run(req);
  await body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters').run(req);

  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { name, hospitalId, phone, email, password } = req.body;

  try {
    // Check if admin already exists
    const existingAdmin = await Admin.findOne({ $or: [{ email }, { phone }] });
    if (existingAdmin) {
      return res.status(400).json({ message: 'Admin already exists!' });
    }

    // Verify hospital existence
    const hospital = await Hospital.findById(hospitalId);
    if (!hospital) {
      return res.status(400).json({ message: 'Invalid hospital ID. Hospital not found.' });
    }

    // Generate OTP and hash the password
    const otp = generateOTP();
    const otpExpiresAt = new Date(Date.now() + 10 * 60 * 1000); // OTP expires in 10 minutes
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create new admin
    const newAdmin = new Admin({
      name,
      hospitalId,
      phone,
      email,
      password: hashedPassword,
      otp,
      otpExpiresAt,
    });

    // Save admin to database
    await newAdmin.save();

    // Add admin ID to hospital's admins array
    hospital.admins.push(newAdmin._id);
    await hospital.save();

    // Send OTP via SMS or Email
    await sendSms(phone, `Your OTP is ${otp}`);
    await sendEmail(email, 'Your OTP Code', `Your OTP is ${otp}`);

    res.status(201).json({ message: 'Admin registered successfully! OTP sent to phone/email.' });

  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error, please try again later.' });
  }
};

// Admin Login and Send OTP
const loginAdmin = async (req, res) => {
  const { phone, email, password } = req.body;

  try {
    // Find admin by phone or email
    const admin = await Admin.findOne({ $or: [{ email }, { phone }] });
    if (!admin) {
      return res.status(404).json({ message: 'Admin not found!' });
    }

    // Compare passwords
    const isPasswordMatch = await bcrypt.compare(password, admin.password);
    if (!isPasswordMatch) {
      return res.status(400).json({ message: 'Invalid credentials!' });
    }

    // Verify hospital existence
    const hospital = await Hospital.findById(admin.hospitalId);
    if (!hospital) {
      return res.status(400).json({ message: 'Associated hospital not found. Contact support.' });
    }

    // Generate OTP and update OTP-related fields
    const otp = generateOTP();
    const otpExpiresAt = new Date(Date.now() + 10 * 60 * 1000); // OTP expires in 10 minutes
    admin.otp = otp;
    admin.otpExpiresAt = otpExpiresAt;

    // Save updated admin data
    await admin.save();

    // Send OTP via SMS or Email
    await sendSms(admin.phone, `Your OTP is ${otp}`);
    await sendEmail(admin.email, 'Your OTP Code', `Your OTP is ${otp}`);

    res.status(200).json({ message: 'OTP sent to phone/email for verification.' });

  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error, please try again later.' });
  }
};

// Verify OTP for Admin
const verifyOTP = async (req, res) => {
  const { phone, email, otp } = req.body;

  try {
    // Find admin by phone or email
    const admin = await Admin.findOne({ $or: [{ email }, { phone }] });
    if (!admin) {
      return res.status(404).json({ message: 'Admin not found!' });
    }

    // Check if OTP is expired
    if (isOTPExpired(admin.otpExpiresAt)) {
      return res.status(400).json({ message: 'OTP has expired, please request a new one.' });
    }

    // Check if OTP is correct
    if (admin.otp !== otp) {
      return res.status(400).json({ message: 'Invalid OTP!' });
    }

    // Mark admin as verified
    admin.isVerified = true;
    await admin.save();

    // Generate JWT token for the admin
    const token = jwt.sign({ adminId: admin._id }, process.env.JWT_SECRET, { expiresIn: '1h' });

    res.status(200).json({ message: 'OTP verified successfully!', token });

  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error, please try again later.' });
  }
};

// Get Doctor List for Admin Dashboard
const getDoctorList = async (req, res) => {
  try {
    // Fetch the list of doctors
    const doctors = await Doctor.find({ hospitalId: req.query.hospitalId });
    res.status(200).json({ doctors });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error fetching doctor list.' });
  }
};


const getAllQueues = async (req, res) => {
  try {
    const queues = await Queue.find().populate('doctor hospital');
    res.json({ success: true, queues });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// ✅ Delete queue by ID
const deleteQueueById = async (req, res) => {
  try {
    const { id } = req.params;
    await Queue.findByIdAndDelete(id);
    res.json({ success: true, message: 'Queue deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// ✅ Update queue status (helped/cancelled/etc.)
const updateQueueStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const updated = await Queue.findByIdAndUpdate(id, { status }, { new: true });
    res.json({ success: true, queue: updated });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

const getAllPatients = async (req, res) => {
  try {
    const { hospitalId, doctorId, status } = req.query;

    const filter = {};
    if (hospitalId) filter.hospitalId = hospitalId;
    if (doctorId) filter.doctorId = doctorId;
    if (status) filter.status = status;

    const queues = await Queue.find(filter)
      .populate('doctorId', 'name')
      .populate('hospitalId', 'name')
      .sort({ createdAt: -1 });

    res.status(200).json({ queues });
  } catch (error) {
    console.error('Admin error fetching patients:', error);
    res.status(500).json({ error: 'Error fetching patients for admin.' });
  }
};

// Admin: Update Doctor's Fee Structure
const updateDoctorFees = async (req, res) => {
  try {
    const { doctorId, normalFee, emergencyFee ,availableSlots} = req.body;

    // Check if admin is authorized
    if (!req.user || req.user.role !== 'admin') {
      return res.status(403).json({ message: "Access denied. Admins only." });
    }

    // Find the doctor and update fees
    const doctor = await Doctor.findById(doctorId);
    if (!doctor) {
      return res.status(404).json({ message: "Doctor not found" });
    }

    doctor.normalFee = normalFee;
    doctor.emergencyFee = emergencyFee;
    doctor.availableSlots = availableSlots;
    await doctor.save();

    return res.status(200).json({ message: "Doctor fees updated successfully", doctor });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Internal server error" });
  }
};


module.exports = { registerAdmin, verifyOTP, loginAdmin, getDoctorList,getAllQueues,deleteQueueById,updateQueueStatus,getAllPatients,updateDoctorFees};