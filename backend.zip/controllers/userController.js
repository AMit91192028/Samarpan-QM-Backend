const User = require('../models/User');
const { generateOTP, isOTPExpired } = require('../utils/otpUtils');
const { sendEmail } = require('../utils/mailer');
const { sendSms } = require('../utils/sendSms');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { generateOtpToken, generateAccessToken } = require('../utils/jwt');
// Register User and Send OTP
const registerUser = async (req, res) => {
  const { name, phone, email, password } = req.body;

  try {
    // Check if user already exists
    const existingUser = await User.findOne({ $or: [{ email }, { phone }] });
    if (existingUser) {
      return res.status(400).json({ message: 'User already exists!' });
    }

    // Generate OTP and hash the password
    const otp = generateOTP();
    const otpExpiresAt = new Date(Date.now() + 10 * 60 * 1000); // OTP expires in 10 minutes
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create new user
    const newUser = new User({
      name,
      phone,
      email,
      password: hashedPassword,
      otp,
      otpExpiresAt,
    });

    // Save user to database
    await newUser.save();

    // Send OTP via SMS or Email
    await sendSms(phone, `Your OTP is ${otp}`);  // Uncomment if using SMS
    await sendEmail(email, 'Your OTP Code', `Your OTP is ${otp}`); // Uncomment if using email
    const token = generateOtpToken({ phoneNumber: phone })
    res.status(201).json({ message: 'User registered successfully! OTP sent to phone/email.' });

  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error, please try again later.' });
  }
};

// Login User and Send OTP
const loginUser = async (req, res) => {
  const { phone, email, password } = req.body;

  try {
    // Find user by phone or email
    const user = await User.findOne({ $or: [{ email }, { phone }] });
    if (!user) {
      return res.status(404).json({ message: 'User not found!' });
    }

    // Compare passwords
    const isPasswordMatch = await bcrypt.compare(password, user.password);
    if (!isPasswordMatch) {
      return res.status(400).json({ message: 'Invalid credentials!' });
    }

    // Generate OTP and update OTP-related fields
    const otp = generateOTP();
    const otpExpiresAt = new Date(Date.now() + 10 * 60 * 1000); // OTP expires in 10 minutes
    user.otp = otp;
    user.otpExpiresAt = otpExpiresAt;

    // Save updated user data
    await user.save();

    // Send OTP via SMS or Email
    await sendSms(user.phone, `Your OTP is ${otp}`);  // Uncomment if using SMS
    await sendEmail(user.email, 'Your OTP Code', `Your OTP is ${otp}`); // Uncomment if using email

    res.status(200).json({ message: 'OTP sent to phone/email for verification.' });

  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error, please try again later.' });
  }
};

// Verify OTP
const verifyOtp = async (req, res) => {
  const { phone, email, otp } = req.body;

  try {
    // Find user by phone or email
    const user = await User.findOne({ $or: [{ email }, { phone }] });
    if (!user) {
      return res.status(404).json({ message: 'User not found!' });
    }

    // Check if OTP is expired
    if (isOTPExpired(user.otpExpiresAt)) {
      return res.status(400).json({ message: 'OTP has expired, please request a new one.' });
    }

    // Check if OTP is correct
    if (user.otp !== otp) {
      return res.status(400).json({ message: 'Invalid OTP!' });
    }

    // Mark user as verified
    user.isVerified = true;
    await user.save();

    // Generate JWT token for the user
    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });

    res.status(200).json({ message: 'OTP verified successfully!', token });

  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error, please try again later.' });
  }
};

module.exports = { registerUser, loginUser, verifyOtp };
