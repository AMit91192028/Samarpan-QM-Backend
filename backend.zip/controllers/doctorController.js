const Doctor = require('../models/Doctor');
const Hospital = require('../models/Hospital'); // Import Hospital model
const { body, validationResult } = require('express-validator');

// Add a new doctor
const addDoctor = async (req, res) => {
  await body('name').notEmpty().withMessage('Name is required').run(req);
  await body('specialization').notEmpty().withMessage('Specialization is required').run(req);
  await body('phone').notEmpty().withMessage('Phone is required').run(req);
  await body('email').isEmail().withMessage('Invalid email').run(req);
  await body('hospitalId').notEmpty().withMessage('Hospital ID is required').run(req);
  await body('yearsOfExperience').isNumeric().withMessage('Years of experience must be a number').run(req);
  await body('isAvailable').isBoolean().withMessage('Availability must be a boolean').run(req);

  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { name, specialization, phone, email, hospitalId, yearsOfExperience, isAvailable } = req.body;

  try {
    // Check if the doctor already exists
    const existingDoctor = await Doctor.findOne({ $or: [{ phone }, { email }] });
    if (existingDoctor) {
      return res.status(400).json({ message: 'Doctor already exists!' });
    }

    // Verify hospital existence
    const hospital = await Hospital.findById(hospitalId);
    if (!hospital) {
      return res.status(400).json({ message: 'Invalid hospital ID. Hospital not found.' });
    }

    // Create a new doctor
    const imagePath = req.file ? req.file.filename : null;
    const newDoctor = new Doctor({
      name,
      specialization,
      image:imagePath,
      phone,
      email,
      hospitalId,
      yearsOfExperience,
      isAvailable,
    });

    // Save doctor to database
    await newDoctor.save();

    // Add doctor ID to hospital's doctors array
    hospital.doctors.push(newDoctor._id);
    await hospital.save();

    res.status(201).json({ message: 'Doctor added successfully!' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error, please try again later.' });
  }
};

// Get list of doctors for a specific hospital
const getDoctorsByHospital = async (req, res) => {
  const { hospitalId } = req.params;

  try {
    // Verify hospital existence (optional, but recommended)
    const hospital = await Hospital.findById(hospitalId);
    if (!hospital) {
      return res.status(400).json({ message: 'Invalid hospital ID. Hospital not found.' });
    }

    const doctors = await Doctor.find({ hospitalId });
    res.status(200).json({ doctors });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error fetching doctor list.' });
  }
};

// Get doctor by ID
const getDoctorById = async (req, res) => {
  const { doctorId } = req.params;

  try {
    const doctor = await Doctor.findById(doctorId);
    if (!doctor) {
      return res.status(404).json({ message: 'Doctor not found.' });
    }
    res.status(200).json({ doctor });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error fetching doctor details.' });
  }
};

module.exports = { addDoctor, getDoctorsByHospital, getDoctorById };