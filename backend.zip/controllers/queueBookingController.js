const jwt = require('jsonwebtoken');
const Doctor = require('../models/Doctor');
const Hospital = require('../models/Hospital');
const Queue = require('../models/Queue');
const { sendSMS } = require('../utils/sendSms');
const { notifyNextInQueue } = require('../utils/notifyNext');
const generateSecureTokenNumber = require('../utils/tokenGenrator');

// Check Queue status
const checkStatus = async (req, res) => {
  try {
    const queue = await Queue.findById(req.queueId);
    if (!queue) return res.status(404).json({ error: 'Queue not found' });

    const allConfirmed = await Queue.find({
      doctorId: queue.doctorId,
      status: 'Confirmed',
    }).sort({ createdAt: 1 });

    const position = allConfirmed.findIndex(q => q._id.equals(queue._id)) + 1;

    res.status(200).json({
      status: queue.status,
      queue,
      position,
      totalConfirmed: allConfirmed.length,
    });
  } catch (error) {
    console.error('Error fetching queue status:', error);
    res.status(500).json({ error: 'Error fetching queue status' });
  }
};

// Book Queue
const bookQueue = async (req, res) => {
  try {
    const { patientName, age, diseaseDescription, phoneNumber, doctorId, hospitalId } = req.body;

    const doctor = await Doctor.findById(doctorId);
    const hospital = await Hospital.findById(hospitalId);

    if (!doctor || !hospital) {
      return res.status(400).json({ error: 'Invalid Doctor or Hospital ID' });
    }

    const tokenNumber = generateSecureTokenNumber();
    const otp = Math.floor(100000 + Math.random() * 900000).toString();

    const newQueue = new Queue({
      patientName,
      age,
      diseaseDescription,
      phoneNumber,
      doctorId,
      hospitalId,
      status: 'Booked',
      tokenNumber,
      otp,
    });

    const savedQueue = await newQueue.save();

    const token = jwt.sign({ queueId: savedQueue._id }, process.env.JWT_SECRET, {
      expiresIn: '15m',
    });

    const bookingMessage = `Your queue token is ${tokenNumber}. You can visit Dr. ${doctor.name} at ${hospital.name}. Patient: ${patientName}, Age: ${age}, Disease: ${diseaseDescription}`;
    await sendSMS(phoneNumber, bookingMessage);

    const otpMessage = `Your OTP for queue confirmation is ${otp}`;
    await sendSMS(phoneNumber, otpMessage);

    res.status(200).json({
      message: 'Queue booked successfully! OTP sent.',
      token,
      queueDetails: savedQueue,
    });
  } catch (error) {
    console.error('Error booking the queue:', error);
    res.status(500).json({ error: 'Something went wrong while booking the queue.' });
  }
};

// Verify OTP
const verifyOtp = async (req, res) => {
  try {
    const { token, otp } = req.body;

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const queueId = decoded.queueId;

    const queue = await Queue.findById(queueId);
    if (!queue) return res.status(404).json({ error: 'Queue not found' });

    if (queue.otp === otp) {
      queue.status = 'Confirmed';
      await queue.save();
      await notifyNextInQueue(queue);

      const verifiedToken = jwt.sign(
        { queueId: queue._id, verified: true },
        process.env.JWT_SECRET,
        { expiresIn: '2h' }
      );

      return res.status(200).json({
        message: 'OTP verified successfully!',
        verifiedToken,
      });
    } else {
      return res.status(400).json({ error: 'Invalid OTP' });
    }
  } catch (error) {
    console.error('Error during OTP verification:', error);
    res.status(500).json({ error: 'Something went wrong during OTP verification.' });
  }
};

// Update Queue Status
const updateStatus = async (req, res) => {
  try {
    const { queueId } = req.params;
    const { newStatus } = req.body;

    const allowedStatuses = ['Served', 'Skipped', 'Cancelled'];
    if (!allowedStatuses.includes(newStatus)) {
      return res.status(400).json({ error: 'Invalid status' });
    }

    const queue = await Queue.findById(queueId);
    if (!queue) return res.status(404).json({ error: 'Queue not found' });

    queue.status = newStatus;
    await queue.save();

    if (newStatus === 'Served') {
      await notifyNextInQueue(queue);
    }

    res.status(200).json({ message: 'Queue status updated', queue });
  } catch (error) {
    console.error('Error updating queue status:', error);
    res.status(500).json({ error: 'Server error while updating status.' });
  }
};

module.exports = { checkStatus, bookQueue, verifyOtp, updateStatus };
